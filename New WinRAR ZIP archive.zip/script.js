let ModelList = document.querySelector(".model-list");
let CloseX = document.querySelector(".close");
let menuBtn = document.querySelector(".menu-btn");
let overLay = document.querySelector(".over-lay");
console.log(menuBtn)

menuBtn.addEventListener('click', function() {
    if (ModelList.style.display === 'none') {
        ModelList.style.display = 'block';
        overLay.style.display = 'block';
    } else {
        ModelList.style.display = 'none';
        overLay.style.display = 'none';
    }
});
CloseX.addEventListener('click', function() {
    if (ModelList.style.display === 'block') {
        ModelList.style.display = 'none';
        overLay.style.display = 'none';
    } else {
        ModelList.style.display = 'block';
        overLay.style.display = 'none';
    }
});

// change news images 



//   scroll 
let scroll = document.querySelector(".scroll")
scroll.onclick = function (){
    window.scrollTo({
        top : 0 ,
        behavior : "smooth"
    })
};